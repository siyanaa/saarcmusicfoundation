<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Team;
use App\Models\About;
// use App\Models\Service;

use App\Models\Course;
use App\Models\Demand;
use App\Models\Contact;
use App\Models\Country;
use App\Models\Service;
use App\Models\Category;
use App\Models\CoverImage;
use App\Models\SiteSetting;
use App\Models\Testimonial;
use App\Models\PhotoGallery;
use Illuminate\Http\Request;
use App\Models\BlogPostsCategory;
use App\Models\VideoGallery; 
use Illuminate\Support\Facades\Log;

class FrontViewController extends Controller
{
   
        public function index()
        {
            $sitesetting = SiteSetting::first();
            $about = About::first();
            $services = Service::latest()->get()->take(6);
            $contacts = Contact::latest()->get();
            $blogs = BlogPostsCategory::latest()->get()->take(3);
            $testimonials = Testimonial::latest()->get()->take(10);
            $coverImages = CoverImage::all();
            $demands = Demand::latest()->get()->take(12);
            $images = PhotoGallery::latest()->take(6)->get(); // Fetch the photos
            $videos = VideoGallery::latest()->take(6)->get(); // Fetch the videos
            
            // Fetch the first category
            $firstCategory = Category::first();
            $posts = $firstCategory ? $firstCategory->posts()->latest()->take(6)->get() : collect();
    
            return view('frontend.index', compact(
                'services', 
                'contacts', 
                'blogs', 
                'sitesetting', 
                'testimonials', 
                'coverImages', 
                'demands', 
                'about', 
                'posts', 
                'firstCategory', 
                'images', // Pass the photos to the view
                'videos'  // Pass the videos to the view
            ));
        
    }
    
    public function singlePost($slug)
    {
        $post = Post::where('slug', $slug)->firstOrFail();
        $relatedPosts = Post::where('id', '!=', $post->id)->get();

        return view('frontend.posts', compact('post', 'relatedPosts'));
    }

   
        
            public function showTeam($role)
            {
                Log::info("Received type: " . $role);
        
                $role = $this->convertTypeToRole($role);
                Log::info("Converted role: " . $role);
        
                if ($role === null) {
                    Log::warning("Invalid team type: " . $role);
                    abort(404);
                }
        
                $teams = Team::where('role', $role)->get();
                Log::info("Number of teams found: " . $teams->count());
        
                // Dump the first team for debugging
                if ($teams->isNotEmpty()) {
                    Log::info("First team: " . $teams->first());
                }
        
                $page_title = $role;
                $services = Service::latest()->take(6)->get();
                $sitesetting = SiteSetting::first();
                $categories = Category::latest()->take(10)->get();
                $about = About::first();
                $posts = Post::with('category')->latest()->take(3)->get();
        
                return view('frontend.team', compact(
                    'teams',
                    'sitesetting',
                    'categories',
                    'about',
                    'page_title',
                    'services',
                    'posts',
                    'role'  // Adding 'type' for additional context in the view
                ));
            }
        
            // private function convertTypeToRole($type)
            // {
            //     switch (strtolower($type)) {
            //         case 'executive':
            //             return 'Executive Team';
            //         case 'advisory':
            //             return 'Advisory Team';
            //         case 'others':
            //             return 'Others';
            //         default:
            //             return null;
            //     }
            // }
        
    private function convertTypeToRole($role)
    {
        switch ($role) {
            case 'executive':
                return 'Executive Team';
            case 'advisory':
                return 'Advisory Team';
            case 'others':
                return 'Others';
            default:
                return null;
        }
    }

}
